New plugins manually added go here.

If you manually add a plugin here hit add manual plugin.
Then the software will check this folder and treat it
as if it was just downloaded from online.